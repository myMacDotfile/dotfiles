#!/bin/bash

$PYTHON setup.py install --old-and-unmanageable
