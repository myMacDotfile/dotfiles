#!/bin/bash

$PYTHON setup.py install
